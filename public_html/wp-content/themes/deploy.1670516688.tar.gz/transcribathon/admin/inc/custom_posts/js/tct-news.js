var tct_record_type;
jQuery(document).ready(function($){
	"use strict";
	// Disable default Meta-Box behaviour. The id corresponds to what is claimed in "add_meta_box"
	$('#newsfields').parent().sortable({ disabled: true }); // remove the "sortable"-attribute
	$('#newsfields.postbox .hndle').removeClass('hndle'); // remove the handle
	
	
			
});
