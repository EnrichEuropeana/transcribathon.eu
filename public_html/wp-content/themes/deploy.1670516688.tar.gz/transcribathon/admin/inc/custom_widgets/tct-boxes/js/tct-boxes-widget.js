jQuery(document).ready(function() {
	jQuery('a.flatlink').each(function(){
		jQuery(this).css({'top':'-100px','position':'absolute','z-index':'50'});
	});
	
		
});




















