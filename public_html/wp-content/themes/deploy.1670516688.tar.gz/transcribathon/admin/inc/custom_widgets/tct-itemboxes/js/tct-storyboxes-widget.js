jQuery(document).ready(function() {
	
	
		
});

function tct_storybox_getNextTwelve(modID,stand){
	"use strict";
	alert(jQuery('#'+modID+' div.tct_sry_'+stand).text());
}


















